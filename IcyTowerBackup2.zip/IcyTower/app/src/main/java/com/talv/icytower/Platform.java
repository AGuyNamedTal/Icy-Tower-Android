package com.talv.icytower;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;

import java.util.HashMap;

public class Platform {
    public enum PlatformTypes {
        BASIC_0(R.drawable.platform_basic_0);
        public final int resId;

        PlatformTypes(int resId) {
            this.resId = resId;
        }
    }

    private static final PlatformTypes[][] platformsByLevel = new PlatformTypes[][]{
            new PlatformTypes[]{PlatformTypes.BASIC_0}
    };


    private static HashMap<PlatformTypes, Bitmap> basicTiles = new HashMap<>();


    public Rect rect;
    public Bitmap image;
    public PlatformTypes type;
    public boolean enabled = true;
    public int platformNumber;


    public Platform(PlatformTypes type, int num, int x, int y, int width, int height) {
        platformNumber = num;
        image = ImageHelper.tileImageX(basicTiles.get(type), width, height, false);
        rect = Engine.rectFromWidthHeight(x, y, width, height);
    }

    protected Paint getPaint() {
        return Engine.defaultPaint;
    }

    public void render(Canvas canvas, Engine engine) {
        canvas.drawBitmap(image, rect.left, rect.top - engine.cameraY, getPaint());
    }

    public void recycle() {
        image.recycle();
        enabled = false;
    }

    public static void loadBitmaps(Resources resources, int level) {
        emptyLoadedPlatforms();
        PlatformTypes[] platformTypes = platformsByLevel[level];
        for (PlatformTypes platformType : platformTypes) {
            basicTiles.put(platformType, BitmapFactory.decodeResource(resources, platformType.resId));
        }
    }

    public static void emptyLoadedPlatforms() {
        for (Bitmap img : basicTiles.values()) {
            if (img != null) {
                img.recycle();
            }
        }
        basicTiles.clear();
    }


}
