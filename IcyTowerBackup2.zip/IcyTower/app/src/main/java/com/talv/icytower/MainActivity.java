package com.talv.icytower;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {

    private static final boolean LOGIN_REQUIRED = true;
    public static FirebaseAuth auth;
    public static FirebaseDatabase database;
    public static DatabaseReference dbRef;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();
        dbRef = database.getReference();

        Button playBtn = findViewById(R.id.playBtn);
        playBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (LOGIN_REQUIRED) {
                    FirebaseUser currentUser = auth.getCurrentUser();
                    if (currentUser == null) {
                        // login
                        startActivity(new Intent(MainActivity.this, LoginActivity.class));
                    } else {
                        startActivity(new Intent(MainActivity.this, GameActivity.class));
                    }
                } else {
                    startActivity(new Intent(MainActivity.this, GameActivity.class));
                }

            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();

    }
}
