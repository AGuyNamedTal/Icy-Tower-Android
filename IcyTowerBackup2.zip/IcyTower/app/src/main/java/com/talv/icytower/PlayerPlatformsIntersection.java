package com.talv.icytower;

import android.util.Log;

public class PlayerPlatformsIntersection {

    public int newY;
    public boolean didIntersect = false;

    public PlayerPlatformsIntersection(int newY, boolean didIntersect) {
        this.newY = newY;
        if (didIntersect == true){
            Log.d("afdsa", "");
        }
        this.didIntersect = didIntersect;
    }

    public PlayerPlatformsIntersection(int newY) {
        this.newY = newY;
    }
}
