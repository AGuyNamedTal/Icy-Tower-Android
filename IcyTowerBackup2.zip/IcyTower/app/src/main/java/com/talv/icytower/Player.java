package com.talv.icytower;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.util.Log;

import java.util.HashMap;
import java.util.LinkedList;

import static com.talv.icytower.Engine.PLAYER_SIZE_MULTIPLE;

public abstract class Player {

    public enum Direction {
        LEFT,
        RIGHT
    }


    public enum PlayerState {
        STANDING,
        SIDE_STAND,
        MOVING,
        JUMPING,
        JUMP_MOVE,
        STARRING
    }

    protected float playerSizeMultiple;

    protected int stateUpdateTime = 0;

    private static final int TIME_FROM_SIDE_STAND_TO_STANDING = 400;


    public static final float ACCELERATION_SPEED = PLAYER_SIZE_MULTIPLE * 0.066f / 1.5f;

    public static final float DECELERATION_SPEED = ACCELERATION_SPEED * 2f;

    public static final float MAX_SPEED = PLAYER_SIZE_MULTIPLE * 33.333f / 1.5f;
    public static final float MIN_SPEED = MAX_SPEED / 10f;
    public static final float REACTION_FORCE_MULTIPLE = 0.8f;

    //public static float JUMP_HEIGHT = 125f;
    public static final float VERTICAL_DECELERATION = DECELERATION_SPEED * 0.8f;
    public static final float MAX_FALL_SPEED = MIN_SPEED * 0.3f;
    public static final float MIN_JUMP_SPEED = -MAX_FALL_SPEED * 0.8f;
    public static final float HORIZONTAL_TO_VERTICAL_MULTIPLE = 0.04f;

    public static float currentVerticalSpeed = 0;


    private float currentSpeed = 0;

    private float externalSpeed = 0;


    public Direction currentDirection = Direction.RIGHT;
    public PlayerState currentState = PlayerState.STANDING;
    public Rect rect;


    protected HashMap<PlayerState, BitmapAnimation> animations;

    private PlayerControls playerControls;

    public Player(Resources resources, float playerSizeMultiple) {
        this.playerSizeMultiple = playerSizeMultiple;
        initializeAnimations(resources);
        updateStateAndAnimation(PlayerState.STANDING, 0);

        playerControls = new PlayerControls();
    }


    abstract void initializeAnimations(Resources resources);

    abstract void updateStateAndAnimation(PlayerState newState, int msPassed);


    abstract Bitmap getCurrentImage();


    public void render(Canvas canvas, Engine engine) {
        canvas.drawBitmap(getCurrentImage(), rect.left, rect.top - engine.cameraY, Engine.defaultPaint);

    }

    public void updatePlayer(int msPassed, Engine engine) {


        int activeControls = engine.gameCanvas.getActiveControls();
        if (GameCanvas.Controls.checkActive(activeControls, GameCanvas.Controls.ARROW_LEFT) &&
                GameCanvas.Controls.checkActive(activeControls, GameCanvas.Controls.ARROW_RIGHT)) {
            activeControls &= ~GameCanvas.Controls.ARROW_LEFT;
            activeControls &= ~GameCanvas.Controls.ARROW_RIGHT;
        }
        playerControls.passParameters(msPassed, engine);
        playerControls.controlFunctions[activeControls].run();

        int newX = (int) (rect.left + currentSpeed + externalSpeed);
        // decelerate external speed
        if (Math.abs(externalSpeed) > 0) {
            if (externalSpeed > 0) {
                externalSpeed = Math.max(externalSpeed - DECELERATION_SPEED * msPassed, 0);
            } else {
                externalSpeed = Math.min(externalSpeed + DECELERATION_SPEED * msPassed, 0);
            }
        }

        // handle wall collision
        if (newX < 0) {
            newX = 0;
            currentDirection = Direction.RIGHT;
            externalSpeed = currentSpeed * -REACTION_FORCE_MULTIPLE;
            currentSpeed = 0;
        } else if (newX > engine.cameraWidth - rect.width()) {
            newX = engine.cameraWidth - rect.width();
            currentDirection = Direction.LEFT;
            externalSpeed = currentSpeed * -REACTION_FORCE_MULTIPLE;
            currentSpeed = 0;
        }

        // handle direction change
        if (rect.left > newX) {
            currentDirection = Direction.LEFT;
        } else {
            currentDirection = Direction.RIGHT;
        }

        if (currentVerticalSpeed >= 0 /*not jumping*/ && !isOnPlatform(engine.platforms)) {
            currentVerticalSpeed = Math.min(MAX_FALL_SPEED, currentVerticalSpeed + VERTICAL_DECELERATION);
        }

        // handle vertical speed (jump/fall)
        if (currentVerticalSpeed != 0) {
            jumpTick(engine, msPassed);
        }
        // handle gravity

        // handle animation
        PlayerState newState = null;
        if (newX != rect.left) {
            if (currentVerticalSpeed == 0) {
                if (Math.abs(currentSpeed) < MAX_SPEED / 10f) {
                    newState = PlayerState.SIDE_STAND;
                } else {
                    newState = PlayerState.MOVING;
                }
            } else {
                newState = PlayerState.JUMP_MOVE;
            }
        }


        if (newState != null)
            updateStateAndAnimation(newState, msPassed);
        RectHelper.setRectX(rect, newX);


        //update camera:


        // handle gravity
        //check if should fall

        /*
        boolean shouldFall = !isPlatformBelow(engine.platforms) && !(isJumping());
        if (!shouldFall) {
            System.out.println("h");
        }
        if (Debug.LOG_JUMP)
            Log.d("jump", "Should Fall: " + shouldFall);
        if (shouldFall) {
            int newY = (int) (rect.top + MAX_FALL_SPEED * msPassed);
            fall(newY, engine.platforms, msPassed);
        } else {
            if (isFalling()) {
                stopFalling(msPassed, rect.top);
            }
            if (isJumping()) {
                jumpTick(engine.platforms, msPassed);
            }
        }
        */
    }


    private boolean isJumping() {
        return (currentState == PlayerState.JUMPING || currentState == PlayerState.JUMP_MOVE) && currentVerticalSpeed < 0;
    }

    private boolean isFalling() {
        return (currentState == PlayerState.JUMPING || currentState == PlayerState.JUMP_MOVE) && currentVerticalSpeed > 0;
    }

    private boolean isPlatformBelow(LinkedList<Platform> platforms) {
        for (Platform platform :
                platforms) {
            if (Engine.isRectBelowRect(platform.rect, rect)) {
                return true;
            }
        }
        return false;
    }

    private boolean isOnPlatform(LinkedList<Platform> platforms) {
        for (Platform platform :
                platforms) {
            if (Engine.isRectOnRect(rect, platform.rect)) {
                return true;
            }
        }
        return false;
    }
  /*  private void fall(int newY, List<Platform> platforms, int msPassed) {
        currentJumpState = JumpState.FALLING;
        int yAfterIntersection = newY;
        boolean didIntersect = false;
        for (Platform plat : platforms) {
            PlayerPlatformsIntersection intersection =
                    Engine.doesPlatformIntersectWithMovementY(rect, yAfterIntersection, plat.rect);
            if (intersection.didIntersect) {
                yAfterIntersection = Math.min(yAfterIntersection, intersection.newY);
                didIntersect = true;
            }
        }
        if (didIntersect /*intersected with platform*/

    /*) {        stopFalling(msPassed, yAfterIntersection);
        } else {
            currentJumpState = JumpState.FALLING;
            RectHelper.setRectY(rect, newY);
        }
}*/


    private void jumpTick(Engine engine, int msPassed) {

        float toMove = currentVerticalSpeed * msPassed;
        // decelerate
        if (currentVerticalSpeed > 0) {
            // falling down
            //currentVerticalSpeed = Math.min(MAX_FALL_SPEED, currentVerticalSpeed + VERTICAL_DECELERATION);

        } else {
            // jumping up
            currentVerticalSpeed += VERTICAL_DECELERATION;
        }
        int newY = (int) (rect.top + toMove);

        if (toMove > 0) {
            // falling
            int yAfterIntersection = newY;
            boolean didIntersect = false;
            for (Platform plat : engine.platforms) {
                PlayerPlatformsIntersection intersection =
                        Engine.doesPlatformIntersectWithMovementY(rect, yAfterIntersection, plat.rect);
                if (intersection.didIntersect) {
                    yAfterIntersection = Math.min(yAfterIntersection, intersection.newY);
                    didIntersect = true;
                }
            }
            if (didIntersect /*intersected with platform*/) {
                updateStateAndAnimation(PlayerState.STANDING, msPassed);
                currentVerticalSpeed = 0;
                newY = yAfterIntersection;
            }
        } else {
            // jumping up
            // update camera
            //      if (newY < engine.cameraY + engine.cameraHeight * 0.5f)
//                engine.externalCameraSpeed = Math.max(currentVerticalSpeed , MIN_JUMP_SPEED);
        }
        RectHelper.setRectY(rect, newY);
        if (currentSpeed == 0 && System.currentTimeMillis() - stateUpdateTime >= TIME_FROM_SIDE_STAND_TO_STANDING) {
            updateStateAndAnimation(PlayerState.JUMPING, msPassed);
        } else {
            updateStateAndAnimation(PlayerState.JUMP_MOVE, msPassed);
        }

/*
        if (newJumpY >= JUMP_HEIGHT) {
            currentJumpState = JumpState.FALLING;
            if (newJumpY > JUMP_HEIGHT) {
                float timeToReachTop = (JUMP_HEIGHT - (getCurrentJumpY())) / currentVerticalSpeed;
                float timeFalling = msPassed - timeToReachTop;
                RectHelper.setRectY(rect, (int) (rect.top - currentVerticalSpeed * timeToReachTop));
                fall((int) (rect.top + timeFalling * MAX_FALL_SPEED), platforms, msPassed);
            }
        } else {
            currentJumpY = newJumpY;
            RectHelper.setRectY(rect, rect.top - (int) toMove);
        }
        if (Debug.LOG_JUMP)
            Log.d("jump", "jump tick, tojump = " + toMove);
*/
    }

    private float calculateJumpingSpeed() {
        return Math.min(-Math.abs(currentSpeed + externalSpeed) * HORIZONTAL_TO_VERTICAL_MULTIPLE, MIN_JUMP_SPEED);
    }

    private class PlayerControls {
        public Runnable[] controlFunctions = new Runnable[GameCanvas.Controls.MAX_FLAGS];
        private int msPassed;

        public void passParameters(int msPassed, Engine engine) {
            this.msPassed = msPassed;

        }

        public PlayerControls() {
            controlFunctions[0] = new Runnable() {
                @Override
                public void run() {
                    stand();
                }
            };
            controlFunctions[GameCanvas.Controls.ARROW_LEFT] = new Runnable() {
                @Override
                public void run() {
                    moveLeft();
                }
            };
            controlFunctions[GameCanvas.Controls.ARROW_RIGHT] = new Runnable() {
                @Override
                public void run() {
                    moveRight();
                }
            };
            controlFunctions[GameCanvas.Controls.ARROW_UP] = new Runnable() {
                @Override
                public void run() {
                    jump(true);
                }
            };
            controlFunctions[GameCanvas.Controls.ARROW_LEFT | GameCanvas.Controls.ARROW_UP] = new Runnable() {
                @Override
                public void run() {
                    moveJumpLeft();
                }
            };
            controlFunctions[GameCanvas.Controls.ARROW_RIGHT | GameCanvas.Controls.ARROW_UP] = new Runnable() {
                @Override
                public void run() {
                    moveJumpRight();
                }
            };
        }

        private void moveLeft() {
            if (Debug.LOG_PLAYER)
                Log.d("player", "MOVING LEFT");
            //updateStateAndAnimation(PlayerState.MOVING, msPassed);
            // currentDirection = Direction.LEFT;

            if (currentSpeed > 0) {
                currentSpeed = -MIN_SPEED;
            }

            currentSpeed -= ACCELERATION_SPEED * msPassed;

            currentSpeed = Math.max(currentSpeed, -MAX_SPEED);
            if (Debug.LOG_SPEED)
                Log.d("speed", String.valueOf(currentSpeed));



            /*
            for (Platform platform : engine.platforms) {
                newX = Math.max(Engine.doesPlatformIntersectWithMovementX(rect, newX, platform.rect), newX);
            }
            */


        }

        private void moveRight() {
            if (Debug.LOG_PLAYER)
                Log.d("player", "MOVING RIGHT");
            // updateStateAndAnimation(PlayerState.MOVING, msPassed);
            // currentDirection = Direction.RIGHT;

            if (currentSpeed < 0) {
                currentSpeed = MIN_SPEED;
            }

            currentSpeed += ACCELERATION_SPEED * msPassed;

            currentSpeed = Math.min(currentSpeed, MAX_SPEED);
            if (Debug.LOG_SPEED)
                Log.d("speed", String.valueOf(currentSpeed));

            /*
            for (Platform platform : engine.platforms) {
                newX = Math.min(Engine.doesPlatformIntersectWithMovementX(rect, newX, platform.rect), newX);
            }
            */
        }


        private void jump(boolean decelerate) {
            if (Debug.LOG_PLAYER)
                Log.d("player", "JUMPING");
            if (decelerate)
                decelerateSpeed();
            boolean cantJump = isJumping() || isFalling();
            if (Debug.LOG_JUMP)
                Log.d("jump", "Can't Jump: " + cantJump);

            if (cantJump) return;
            updateStateAndAnimation(PlayerState.JUMPING, msPassed);
            currentVerticalSpeed = calculateJumpingSpeed();
        }

        private void moveJumpLeft() {
            if (Debug.LOG_PLAYER) Log.d("player", "JUMP MOVE LEFT");
            //JUMP:
            jump(false);

            //MOVE RIGHT:
            moveLeft();
        }

        private void moveJumpRight() {
            if (Debug.LOG_PLAYER) Log.d("player", "JUMP MOVE RIGHT");

            //JUMP:
            jump(false);

            //MOVE RIGHT:
            moveRight();
        }

        private void stand() {
            if (Debug.LOG_PLAYER)
                Log.d("player", "STANDING");

            decelerateSpeed();

            if (currentVerticalSpeed == 0) {
                if (System.currentTimeMillis() - stateUpdateTime >= TIME_FROM_SIDE_STAND_TO_STANDING) {
                    updateStateAndAnimation(PlayerState.STANDING, msPassed);
                }
            }
        }

        private void decelerateSpeed() {
            if (currentSpeed > 0) {
                currentSpeed = Math.max(currentSpeed - DECELERATION_SPEED * msPassed, 0);
            } else {
                currentSpeed = Math.min(currentSpeed + DECELERATION_SPEED * msPassed, 0);
            }
        }


    }


}
