package com.talv.icytower;

public class Debug {

    public static final boolean LOG_ANIMATION = false;
    public static final boolean LOG_MSPASSED = false;
    public static final boolean LOG_PLAYER = false;
    public static final boolean LOG_SPEED = false;
    public static final boolean LOG_JUMP = false;
}
