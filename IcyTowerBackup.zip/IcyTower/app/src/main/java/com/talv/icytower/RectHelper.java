package com.talv.icytower;

import android.graphics.Rect;
import android.util.Log;

public class RectHelper {

    public static void setRectX(Rect rect, int x) {
        rect.set(x, rect.top, x + rect.width(), rect.bottom);
    }

    public static void setRectY(Rect rect, int y) {
        if (Debug.LOG_JUMP)
            Log.d("jump", "Y = " + y);
        rect.set(rect.left, y, rect.right, y + rect.height());
    }
}
