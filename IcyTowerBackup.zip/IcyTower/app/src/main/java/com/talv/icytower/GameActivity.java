package com.talv.icytower;

import android.content.pm.ActivityInfo;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.os.Bundle;
import android.os.Debug;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.WindowManager;

public class GameActivity extends AppCompatActivity {

    private static final int FPS = 60;
    public static final int FRAME_WAIT = 1000 / FPS;

    private Engine engine;
    private GameCanvas gameCanvas;
    private Thread gameThread;


    private boolean gameRun;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        //if (Debug.isDebuggerConnected())
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);


        ScreenScaleManager.updateWidthHeight(getWindowManager().getDefaultDisplay());


        gameCanvas = new GameCanvas(this);
        gameCanvas.setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);


        Resources resources = getResources();

        engine = new Engine(ScreenScaleManager.newWidth, ScreenScaleManager.newHeight, resources, new CoolGuy(resources,
                Engine.PLAYER_SIZE_MULTIPLE), gameCanvas);
        engine.loadLevel0(resources);


        gameRun = true;

        gameThread = new Thread(new Runnable() {
            @Override
            public void run() {
                long lastTime = System.currentTimeMillis();
                while (gameRun) {

                    long currentTime = System.currentTimeMillis();
                    int timeBetweenTicks = Math.min((int) (currentTime - lastTime), 750);
                    lastTime = currentTime;
                    gameTick(timeBetweenTicks);
                    long timeToSleep = Math.max(750 - (System.currentTimeMillis() - lastTime), 0);
                    if (timeToSleep != 0)
                        try {
                            Thread.sleep(FRAME_WAIT);
                        } catch (InterruptedException e) {
                            gameRun = false;
                            break;
                        }
                }
            }
        });
        setContentView(gameCanvas);
    }

    @Override
    protected void onResume() {
        super.onResume();
        gameThread.start();
    }


    @Override
    protected void onPause() {
        super.onPause();
    }

    private void gameTick(int time) {
        if (gameCanvas.holder == null) return;
        engine.updateFrame();
        Canvas canvas = gameCanvas.holder.lockCanvas();
        if (canvas == null) return;
        engine.render(canvas);
        gameCanvas.holder.unlockCanvasAndPost(canvas);
        engine.updateGame(time);

    }


}
