package com.talv.icytower;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.util.Log;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Random;

public class Engine {

    public static final float PLAYER_SIZE_MULTIPLE = 0.7f;

    public static Paint defaultPaint;

    private int platformHeight;
    private final int maxPlatformWidth;
    private final int minPlatformWidth;
    private final float PLAT_CAMERA_MAX_RATIO = PLAYER_SIZE_MULTIPLE * 0.5f;
    private final float PLAT_CAMERA_MIN_RATIO = PLAYER_SIZE_MULTIPLE * 0.3f;


    private Bitmap backgroundImg;
    public LinkedList<Platform> platforms = new LinkedList<>();
    public int cameraY;
    public int cameraHeight;
    public int cameraWidth;


    public float externalCameraSpeed = 0f;
    public float constantCameraSpeed = 0f;
    private static final float CAMERA_SPEED_DECELERATION = PLAYER_SIZE_MULTIPLE * 0.1f;
    private static final float CAMERA_CONSTANT_SPEED_INCREASE = PLAYER_SIZE_MULTIPLE * 0.02f;
    private float cameraWaitToIncrease = Float.POSITIVE_INFINITY;


    private Bitmap frameScaled;
    private Bitmap frame;
    private int renderWidth;
    private int renderHeight;


    private Player player;
    private Random random;

    public GameCanvas gameCanvas;

    static {
        defaultPaint = new Paint();
    }

    public Engine(int renderWidth, int renderHeight, Resources resources, Player player, GameCanvas gameCanvas) {
        this.renderWidth = renderWidth;
        this.renderHeight = renderHeight;
        cameraWidth = ScreenScaleManager.originalWidth;
        cameraHeight = ScreenScaleManager.originalHeight;
        maxPlatformWidth = (int) (cameraWidth * PLAT_CAMERA_MAX_RATIO);
        minPlatformWidth = (int) (cameraWidth * PLAT_CAMERA_MIN_RATIO);
        random = new Random(123);

        backgroundImg = ImageHelper.stretch(BitmapFactory.decodeResource(resources, R.drawable.background_1), cameraWidth, cameraHeight, true);
        frame = Bitmap.createBitmap(cameraWidth, cameraHeight, Bitmap.Config.RGB_565);
        this.player = player;
        this.gameCanvas = gameCanvas;

        gameCanvas.initialize(resources, renderWidth, renderHeight);
    }


    public void render(Canvas canvas) {
        canvas.drawBitmap(frameScaled, 0, 0, defaultPaint);
    }

    public void updateFrame() {
        // draw on frame
        Canvas bitmapCanvas = new Canvas(frame);
        // draw background
        bitmapCanvas.drawBitmap(backgroundImg, 0, 0, defaultPaint);

        // draw platforms
        for (Platform platform : platforms) {
            platform.render(bitmapCanvas, this);
        }

        //draw player
        player.render(bitmapCanvas, this);


        // final render (stretch)
        frameScaled = ImageHelper.stretch(frame, renderWidth, renderHeight, false);

        // add controls

        Canvas finalFrameCanvas = new Canvas(frameScaled);
        gameCanvas.renderControls(finalFrameCanvas);

    }


    public void updateGame(int msPassed) {
        if (Debug.LOG_MSPASSED)
            Log.d("MS PASSED", String.valueOf(msPassed));

        // update and remove platforms
        Iterator<Platform> iterator = platforms.descendingIterator();
        int removed = 0;
        while (iterator.hasNext()) {
            Platform platform = iterator.next();
            if (platform.rect.bottom > cameraY + cameraHeight * 2) {
                platform.recycle();
                iterator.remove();
                removed++;
                continue;
            }
            if (platform instanceof DisappearingPlatform) {
                ((DisappearingPlatform) platform).tick(msPassed);
            }
            if (!platform.enabled) {
                iterator.remove();
            }
        }
        generatePlatforms(removed);

        // update player
        player.updatePlayer(msPassed, this);

        // update camera
        int playerY = player.rect.top;
        float playerRelativeToCamera = ((playerY - cameraY) / (float) cameraHeight);
        if (player.rect.top < cameraY + cameraHeight * 0.25f) {
            externalCameraSpeed = Math.min(externalCameraSpeed + CAMERA_SPEED_DECELERATION * msPassed, Player.MIN_JUMP_SPEED * 1.5f);
        } else {
            // deceleate external camera speed
            //externalCameraSpeed /= 2f;
            externalCameraSpeed = Math.max(0, externalCameraSpeed - msPassed * CAMERA_SPEED_DECELERATION);

        }

        cameraY += (externalCameraSpeed - constantCameraSpeed) * msPassed;
        Log.d("Y", "Difference:  " + ((playerY - cameraY) * 100f / cameraHeight) + "% " + (playerY - cameraY) + ", cam: " + cameraY + ", player: " + playerY);

        if (constantCameraSpeed == 0) {
            if (player.rect.top < 0) {
                constantCameraSpeed = CAMERA_CONSTANT_SPEED_INCREASE;
                cameraWaitToIncrease = 1000 * 1000;
            }
        }
        cameraWaitToIncrease -= msPassed;
        if (cameraWaitToIncrease <= 0) {
            constantCameraSpeed += CAMERA_CONSTANT_SPEED_INCREASE;
            cameraWaitToIncrease = Float.POSITIVE_INFINITY;
        }

    }

    public void generatePlatforms(int count) {
        int lastPlatformY = 0;
        int lastPlatformNum = 0;
        if (platforms.isEmpty()) {
            Log.wtf("PLATFORMS EMPTY", "platfors.isEmpty() == true");
        } else {
            Platform last = platforms.getLast();
            lastPlatformY = last.rect.top;
            lastPlatformNum = last.platformNumber;
        }
        int distanceBetweenPlatforms = (int) (player.rect.height() * 0.9f);
        int height = platformHeight;
        for (int i = 0; i < count; i++) {
            int y = lastPlatformY - distanceBetweenPlatforms - height;
            int width = random.nextInt(maxPlatformWidth - minPlatformWidth) + minPlatformWidth;
            int x = random.nextInt(cameraWidth - width);
            platforms.add(new Platform(Platform.PlatformTypes.BASIC_0, ++lastPlatformNum, x, y, width, height));
            lastPlatformY = y;
        }
    }


    public static boolean doRectsIntersect(Rect rect1, Rect rect2) {
        return rect2.left < rect1.right && rect2.right > rect1.left && rect2.top < rect1.bottom && rect2.bottom > rect1.top;
    }

    public static boolean isRectBelowRect(Rect above, Rect below) {
        return below.left <= above.right && below.right >= above.left && below.top - above.bottom <= 0;
    }

    public static boolean isRectOnRect(Rect above, Rect below) {
        return below.left <= above.right && below.right >= above.left && below.top == above.bottom;
    }

    public static boolean isPointInRect(Rect rect, Point point) {
        return point.x >= rect.left && point.x <= rect.right && point.y >= rect.top && point.y <= rect.bottom;
    }

    public static boolean isPointInRect(Rect rect, int x, int y) {
        return x >= rect.left && x <= rect.right && y >= rect.top && y <= rect.bottom;
    }

    public static Rect rectFromWidthHeight(int x, int y, int width, int height) {
        return new Rect(x, y, x + width, y + height);
    }

    public static PlayerPlatformsIntersection doesPlatformIntersectWithMovementY(Rect oldRect, int newY, Rect platform) {
        // check X intersection
        if (platform.left >= oldRect.right || platform.right <= oldRect.left) {
            return new PlayerPlatformsIntersection(newY);
        }

        boolean moveDown = newY > oldRect.top;
        if (moveDown) {
            int newBottom = newY + oldRect.height();
            if (oldRect.bottom <= platform.top && newBottom >= platform.top) {
                return new PlayerPlatformsIntersection(platform.top - oldRect.height(), true);
            }
        } else {
            // move up
            if (oldRect.top >= platform.bottom && newY <= platform.bottom) {
                return new PlayerPlatformsIntersection(platform.bottom, true);
            }
        }
        return new PlayerPlatformsIntersection(newY);
    }


    public boolean isBelowCamera(int objectBottom) {
        return objectBottom > cameraY + cameraHeight;
    }

    public void loadLevel0(Resources resources) {
        cameraY = 0;
        clearPlatforms();
        Platform.loadBitmaps(resources, 0);

        int playerHeight = (int) (58 * player.playerSizeMultiple);
        int playerWidth = (int) (30 * player.playerSizeMultiple);
        platformHeight = (int) (playerHeight * 0.6f);
        Platform groundPlatform = new Platform(Platform.PlatformTypes.BASIC_0, 0,
                0, cameraHeight - platformHeight - (int) (0.05f * cameraHeight), cameraWidth, platformHeight);
        platforms.add(groundPlatform);
        player.rect = rectFromWidthHeight(cameraWidth / 2, groundPlatform.rect.top - playerHeight, playerWidth, playerHeight);
        generatePlatforms((int) Math.ceil(cameraHeight / (float) (playerHeight)) * 2);

    }

    private void clearPlatforms() {
        Iterator<Platform> iterator = platforms.descendingIterator();
        while (iterator.hasNext()) {
            iterator.next().image.recycle();
            iterator.remove();
        }
    }


}
