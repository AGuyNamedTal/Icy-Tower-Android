package com.talv.icytower;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.PointF;
import android.graphics.Rect;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import java.util.HashMap;
import java.util.Map;

public class GameCanvas extends SurfaceView implements SurfaceHolder.Callback {

    public static class Controls {
        public static final int ARROW_UP = 1 << 0;
        public static final int ARROW_LEFT = 1 << 1;
        public static final int ARROW_RIGHT = 1 << 2;

        public static final int MAX_FLAGS = ARROW_RIGHT << 1;

        public static boolean checkActive(int activeControls, int control){
            return (activeControls & control) == control;
        }
    }

    public final Map<Integer, Rect> CONTROLS_AREAS = new HashMap<>();
    public final Map<Integer, Bitmap> CONTROL_IMAGES = new HashMap<>();

    public static final int MAX_FINGERS = 10;
    public final PointF[] FINGERS = new PointF[MAX_FINGERS];
    //public static PointF[] CLICK_FINGERS = new PointF[MAX_FINGERS];
    public SurfaceHolder holder;


    public GameCanvas(Context context) {
        super(context);
        setClickable(true);
        getHolder().addCallback(this);
    }

    public void initialize(Resources resources, int renderWidth, int renderHeight) {

        int controlSize = (int) (0.18 * renderWidth);
        int controlY = (int) (renderHeight - controlSize - 0.03 * renderHeight);
        Rect upArrow = Engine.rectFromWidthHeight(
                (int) (0.05 * renderWidth),
                controlY,
                controlSize,
                controlSize
        );

        Rect leftArrow = Engine.rectFromWidthHeight(
                (int) (0.5 * renderWidth),
                controlY,
                controlSize,
                controlSize
        );

        Rect rightArrow = Engine.rectFromWidthHeight(
                leftArrow.right + (int)(0.1 * renderWidth),
                controlY,
                controlSize,
                controlSize
        );


        CONTROLS_AREAS.put(Controls.ARROW_UP, upArrow);
        CONTROLS_AREAS.put(Controls.ARROW_LEFT, leftArrow);
        CONTROLS_AREAS.put(Controls.ARROW_RIGHT, rightArrow);

        CONTROL_IMAGES.put(Controls.ARROW_UP,
                ImageHelper.stretch(BitmapFactory.decodeResource(resources, R.drawable.up_arrow), controlSize, controlSize, true));
        CONTROL_IMAGES.put(Controls.ARROW_LEFT,
                ImageHelper.stretch(BitmapFactory.decodeResource(resources, R.drawable.left_arrow), controlSize, controlSize, true));
        CONTROL_IMAGES.put(Controls.ARROW_RIGHT,
                ImageHelper.stretch(BitmapFactory.decodeResource(resources, R.drawable.right_arrow), controlSize, controlSize, true));
    }


    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        this.holder = holder;
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {

    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int pointerCount = event.getPointerCount();
        int cappedPointerCount = pointerCount > MAX_FINGERS ? MAX_FINGERS : pointerCount;
        int actionIndex = event.getActionIndex();
        int action = event.getActionMasked();
        int id = event.getPointerId(actionIndex);
        if ((action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) && id < MAX_FINGERS) {
            FINGERS[id] = new PointF(event.getX(actionIndex), event.getY(actionIndex));
        } else if ((action == MotionEvent.ACTION_POINTER_UP || action == MotionEvent.ACTION_UP) && id < MAX_FINGERS) {
            // CLICK_FINGERS[id] = new PointF(FINGERS[id].x, FINGERS[id].y);
            FINGERS[id] = null;

        }
        for (int i = 0; i < cappedPointerCount; i++) {
            if (FINGERS[i] != null) {
                int index = event.findPointerIndex(i);
                try {
                    FINGERS[index] = new PointF(event.getX(index), event.getY(index));
                }
                catch (IllegalArgumentException ex){
                    Log.d("ERROR", "finger weird", ex);
                    continue;
                }
            }
        }
        return true;
    }

    public void renderControls(Canvas canvas) {
        for (Map.Entry<Integer, Bitmap> entry : CONTROL_IMAGES.entrySet()){
            Rect control = CONTROLS_AREAS.get(entry.getKey());
            canvas.drawBitmap(entry.getValue(), control.left, control.top, Engine.defaultPaint);
        }
    }

    public int getActiveControls(){
        int output = 0;
        PointF[] fingers = FINGERS.clone();
        for (int i = 0; i < GameCanvas.MAX_FINGERS; i++) {
            PointF point = fingers[i];
            if (point != null) {
                for (Map.Entry<Integer, Rect> control :CONTROLS_AREAS.entrySet()) {
                    if (Engine.isPointInRect(control.getValue(), (int) point.x, (int) point.y)) {
                        output |= control.getKey();
                    }
                }
            }
        }
        return output;
    }


}
