package com.talv.icytower;

import static com.talv.icytower.AuthVerifier.isValidEmailAddress;
import static com.talv.icytower.AuthVerifier.isValidPassword;
import static com.talv.icytower.AuthVerifier.isValidUsername;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        findViewById(R.id.want_register).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
                finish();
            }
        });

        final EditText emailEdt = findViewById(R.id.loginEmalTxt);
        final EditText passwordEdt = findViewById(R.id.loginPassTxt);

        findViewById(R.id.loginBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = emailEdt.getText().toString();
                String pass = passwordEdt.getText().toString();
                if (!verifyLoginInput(email, pass)) return;

                MainActivity.auth.signInWithEmailAndPassword(email,pass )
                        .addOnCompleteListener(LoginActivity.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    // Sign in success, update UI with the signed-in user's information
                                    startActivity(new Intent(LoginActivity.this, GameActivity.class));
                                    finish();
                                } else {
                                    // If sign in fails, display a message to the user.
                                    Toast.makeText(LoginActivity.this, "Login failed: " + task.getException(),
                                            Toast.LENGTH_SHORT).show();
                                }


                            }
                        });
            }
        });
    }

    private boolean verifyLoginInput(String email, String password){
        if (!isValidEmailAddress(email)) {
            Toast.makeText(LoginActivity.this, "Invalid email address: " + email, Toast.LENGTH_LONG).show();
            return false;
        }
        if (!isValidPassword(password)) {
            Toast.makeText(LoginActivity.this,
                    "Invalid password (must be 5-20 characters long, contain at least one digit, one uppercase and one lowercase letter)",
                    Toast.LENGTH_LONG).show();
            return false;
        }
        return true;
    }
}
